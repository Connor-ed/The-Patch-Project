gdjs.EditorCode = {};
gdjs.EditorCode.localVariables = [];
gdjs.EditorCode.GDKnobObjects1= [];
gdjs.EditorCode.GDKnobObjects2= [];
gdjs.EditorCode.GDNewToggleSwitchObjects1= [];
gdjs.EditorCode.GDNewToggleSwitchObjects2= [];
gdjs.EditorCode.GDInstuctionsObjects1= [];
gdjs.EditorCode.GDInstuctionsObjects2= [];
gdjs.EditorCode.GDDetail_9595modeObjects1= [];
gdjs.EditorCode.GDDetail_9595modeObjects2= [];
gdjs.EditorCode.GDPlayObjects1= [];
gdjs.EditorCode.GDPlayObjects2= [];
gdjs.EditorCode.GDEditorObjects1= [];
gdjs.EditorCode.GDEditorObjects2= [];
gdjs.EditorCode.GDHomeObjects1= [];
gdjs.EditorCode.GDHomeObjects2= [];
gdjs.EditorCode.GDGlobal_9595SheetObjects1= [];
gdjs.EditorCode.GDGlobal_9595SheetObjects2= [];
gdjs.EditorCode.GDMenuObjects1= [];
gdjs.EditorCode.GDMenuObjects2= [];


gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDKnobObjects1Objects = Hashtable.newFrom({"Knob": gdjs.EditorCode.GDKnobObjects1});
gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDKnobObjects1Objects = Hashtable.newFrom({"Knob": gdjs.EditorCode.GDKnobObjects1});
gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDKnobObjects1Objects = Hashtable.newFrom({"Knob": gdjs.EditorCode.GDKnobObjects1});
gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDEditorObjects1Objects = Hashtable.newFrom({"Editor": gdjs.EditorCode.GDEditorObjects1});
gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDHomeObjects1Objects = Hashtable.newFrom({"Home": gdjs.EditorCode.GDHomeObjects1});
gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDPlayObjects1Objects = Hashtable.newFrom({"Play": gdjs.EditorCode.GDPlayObjects1});
gdjs.EditorCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Knob"), gdjs.EditorCode.GDKnobObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDKnobObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.EditorCode.GDKnobObjects1 */
{for(var i = 0, len = gdjs.EditorCode.GDKnobObjects1.length ;i < len;++i) {
    gdjs.EditorCode.GDKnobObjects1[i].rotate(25, runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Knob"), gdjs.EditorCode.GDKnobObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDKnobObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.EditorCode.GDKnobObjects1 */
{for(var i = 0, len = gdjs.EditorCode.GDKnobObjects1.length ;i < len;++i) {
    gdjs.EditorCode.GDKnobObjects1[i].rotate(-(25), runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isWebGLSupported(runtimeScene);
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Knob"), gdjs.EditorCode.GDKnobObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDKnobObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "r");
}
if (isConditionTrue_0) {
/* Reuse gdjs.EditorCode.GDKnobObjects1 */
{for(var i = 0, len = gdjs.EditorCode.GDKnobObjects1.length ;i < len;++i) {
    gdjs.EditorCode.GDKnobObjects1[i].rotateTowardAngle(0, 0, runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Editor"), gdjs.EditorCode.GDEditorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDEditorObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Editor", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Home"), gdjs.EditorCode.GDHomeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDHomeObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Boot", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Play"), gdjs.EditorCode.GDPlayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.EditorCode.mapOfGDgdjs_9546EditorCode_9546GDPlayObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Simple Pluck - 1.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Detail_mode"), gdjs.EditorCode.GDDetail_9595modeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EditorCode.GDDetail_9595modeObjects1.length;i<l;++i) {
    if ( gdjs.EditorCode.GDDetail_9595modeObjects1[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EditorCode.GDDetail_9595modeObjects1[k] = gdjs.EditorCode.GDDetail_9595modeObjects1[i];
        ++k;
    }
}
gdjs.EditorCode.GDDetail_9595modeObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Global_Sheet"), gdjs.EditorCode.GDGlobal_9595SheetObjects1);
{for(var i = 0, len = gdjs.EditorCode.GDGlobal_9595SheetObjects1.length ;i < len;++i) {
    gdjs.EditorCode.GDGlobal_9595SheetObjects1[i].getBehavior("Animation").setAnimationIndex(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Detail_mode"), gdjs.EditorCode.GDDetail_9595modeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EditorCode.GDDetail_9595modeObjects1.length;i<l;++i) {
    if ( !(gdjs.EditorCode.GDDetail_9595modeObjects1[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.EditorCode.GDDetail_9595modeObjects1[k] = gdjs.EditorCode.GDDetail_9595modeObjects1[i];
        ++k;
    }
}
gdjs.EditorCode.GDDetail_9595modeObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Global_Sheet"), gdjs.EditorCode.GDGlobal_9595SheetObjects1);
{for(var i = 0, len = gdjs.EditorCode.GDGlobal_9595SheetObjects1.length ;i < len;++i) {
    gdjs.EditorCode.GDGlobal_9595SheetObjects1[i].getBehavior("Animation").setAnimationIndex(0);
}
}}

}


};

gdjs.EditorCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.EditorCode.GDKnobObjects1.length = 0;
gdjs.EditorCode.GDKnobObjects2.length = 0;
gdjs.EditorCode.GDNewToggleSwitchObjects1.length = 0;
gdjs.EditorCode.GDNewToggleSwitchObjects2.length = 0;
gdjs.EditorCode.GDInstuctionsObjects1.length = 0;
gdjs.EditorCode.GDInstuctionsObjects2.length = 0;
gdjs.EditorCode.GDDetail_9595modeObjects1.length = 0;
gdjs.EditorCode.GDDetail_9595modeObjects2.length = 0;
gdjs.EditorCode.GDPlayObjects1.length = 0;
gdjs.EditorCode.GDPlayObjects2.length = 0;
gdjs.EditorCode.GDEditorObjects1.length = 0;
gdjs.EditorCode.GDEditorObjects2.length = 0;
gdjs.EditorCode.GDHomeObjects1.length = 0;
gdjs.EditorCode.GDHomeObjects2.length = 0;
gdjs.EditorCode.GDGlobal_9595SheetObjects1.length = 0;
gdjs.EditorCode.GDGlobal_9595SheetObjects2.length = 0;
gdjs.EditorCode.GDMenuObjects1.length = 0;
gdjs.EditorCode.GDMenuObjects2.length = 0;

gdjs.EditorCode.eventsList0(runtimeScene);
gdjs.EditorCode.GDKnobObjects1.length = 0;
gdjs.EditorCode.GDKnobObjects2.length = 0;
gdjs.EditorCode.GDNewToggleSwitchObjects1.length = 0;
gdjs.EditorCode.GDNewToggleSwitchObjects2.length = 0;
gdjs.EditorCode.GDInstuctionsObjects1.length = 0;
gdjs.EditorCode.GDInstuctionsObjects2.length = 0;
gdjs.EditorCode.GDDetail_9595modeObjects1.length = 0;
gdjs.EditorCode.GDDetail_9595modeObjects2.length = 0;
gdjs.EditorCode.GDPlayObjects1.length = 0;
gdjs.EditorCode.GDPlayObjects2.length = 0;
gdjs.EditorCode.GDEditorObjects1.length = 0;
gdjs.EditorCode.GDEditorObjects2.length = 0;
gdjs.EditorCode.GDHomeObjects1.length = 0;
gdjs.EditorCode.GDHomeObjects2.length = 0;
gdjs.EditorCode.GDGlobal_9595SheetObjects1.length = 0;
gdjs.EditorCode.GDGlobal_9595SheetObjects2.length = 0;
gdjs.EditorCode.GDMenuObjects1.length = 0;
gdjs.EditorCode.GDMenuObjects2.length = 0;


return;

}

gdjs['EditorCode'] = gdjs.EditorCode;
