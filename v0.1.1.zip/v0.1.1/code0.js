gdjs.BootCode = {};
gdjs.BootCode.localVariables = [];
gdjs.BootCode.GDmenuObjects1= [];
gdjs.BootCode.GDmenuObjects2= [];
gdjs.BootCode.GDNewSpriteObjects1= [];
gdjs.BootCode.GDNewSpriteObjects2= [];
gdjs.BootCode.GDVersion_9595detailsObjects1= [];
gdjs.BootCode.GDVersion_9595detailsObjects2= [];
gdjs.BootCode.GDPlayObjects1= [];
gdjs.BootCode.GDPlayObjects2= [];
gdjs.BootCode.GDEditorObjects1= [];
gdjs.BootCode.GDEditorObjects2= [];
gdjs.BootCode.GDHomeObjects1= [];
gdjs.BootCode.GDHomeObjects2= [];
gdjs.BootCode.GDGlobal_9595SheetObjects1= [];
gdjs.BootCode.GDGlobal_9595SheetObjects2= [];
gdjs.BootCode.GDMenuObjects1= [];
gdjs.BootCode.GDMenuObjects2= [];


gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDmenuObjects1Objects = Hashtable.newFrom({"menu": gdjs.BootCode.GDmenuObjects1});
gdjs.BootCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("menu"), gdjs.BootCode.GDmenuObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.BootCode.mapOfGDgdjs_9546BootCode_9546GDmenuObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Editor", false);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.BootCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.BootCode.GDmenuObjects1.length = 0;
gdjs.BootCode.GDmenuObjects2.length = 0;
gdjs.BootCode.GDNewSpriteObjects1.length = 0;
gdjs.BootCode.GDNewSpriteObjects2.length = 0;
gdjs.BootCode.GDVersion_9595detailsObjects1.length = 0;
gdjs.BootCode.GDVersion_9595detailsObjects2.length = 0;
gdjs.BootCode.GDPlayObjects1.length = 0;
gdjs.BootCode.GDPlayObjects2.length = 0;
gdjs.BootCode.GDEditorObjects1.length = 0;
gdjs.BootCode.GDEditorObjects2.length = 0;
gdjs.BootCode.GDHomeObjects1.length = 0;
gdjs.BootCode.GDHomeObjects2.length = 0;
gdjs.BootCode.GDGlobal_9595SheetObjects1.length = 0;
gdjs.BootCode.GDGlobal_9595SheetObjects2.length = 0;
gdjs.BootCode.GDMenuObjects1.length = 0;
gdjs.BootCode.GDMenuObjects2.length = 0;

gdjs.BootCode.eventsList0(runtimeScene);
gdjs.BootCode.GDmenuObjects1.length = 0;
gdjs.BootCode.GDmenuObjects2.length = 0;
gdjs.BootCode.GDNewSpriteObjects1.length = 0;
gdjs.BootCode.GDNewSpriteObjects2.length = 0;
gdjs.BootCode.GDVersion_9595detailsObjects1.length = 0;
gdjs.BootCode.GDVersion_9595detailsObjects2.length = 0;
gdjs.BootCode.GDPlayObjects1.length = 0;
gdjs.BootCode.GDPlayObjects2.length = 0;
gdjs.BootCode.GDEditorObjects1.length = 0;
gdjs.BootCode.GDEditorObjects2.length = 0;
gdjs.BootCode.GDHomeObjects1.length = 0;
gdjs.BootCode.GDHomeObjects2.length = 0;
gdjs.BootCode.GDGlobal_9595SheetObjects1.length = 0;
gdjs.BootCode.GDGlobal_9595SheetObjects2.length = 0;
gdjs.BootCode.GDMenuObjects1.length = 0;
gdjs.BootCode.GDMenuObjects2.length = 0;


return;

}

gdjs['BootCode'] = gdjs.BootCode;
