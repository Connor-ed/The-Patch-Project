gdjs.Load_95CDED_95Simple_95Keys_951Code = {};
gdjs.Load_95CDED_95Simple_95Keys_951Code.localVariables = [];
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDKnobObjects1= [];
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDKnobObjects2= [];
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDNewToggleSwitchObjects1= [];
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDNewToggleSwitchObjects2= [];
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDInstuctionsObjects1= [];
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDInstuctionsObjects2= [];
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDDetail_9595modeObjects1= [];
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDDetail_9595modeObjects2= [];
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDINSTObjects1= [];
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDINSTObjects2= [];
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDPlayObjects1= [];
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDPlayObjects2= [];
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDEditorObjects1= [];
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDEditorObjects2= [];
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDHomeObjects1= [];
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDHomeObjects2= [];
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDGlobal_9595SheetObjects1= [];
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDGlobal_9595SheetObjects2= [];
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDMenuObjects1= [];
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDMenuObjects2= [];


gdjs.Load_95CDED_95Simple_95Keys_951Code.mapOfGDgdjs_9546Load_959595CDED_959595Simple_959595Keys_9595951Code_9546GDEditorObjects1Objects = Hashtable.newFrom({"Editor": gdjs.Load_95CDED_95Simple_95Keys_951Code.GDEditorObjects1});
gdjs.Load_95CDED_95Simple_95Keys_951Code.mapOfGDgdjs_9546Load_959595CDED_959595Simple_959595Keys_9595951Code_9546GDHomeObjects1Objects = Hashtable.newFrom({"Home": gdjs.Load_95CDED_95Simple_95Keys_951Code.GDHomeObjects1});
gdjs.Load_95CDED_95Simple_95Keys_951Code.mapOfGDgdjs_9546Load_959595CDED_959595Simple_959595Keys_9595951Code_9546GDPlayObjects1Objects = Hashtable.newFrom({"Play": gdjs.Load_95CDED_95Simple_95Keys_951Code.GDPlayObjects1});
gdjs.Load_95CDED_95Simple_95Keys_951Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "r");
if (isConditionTrue_0) {
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Editor"), gdjs.Load_95CDED_95Simple_95Keys_951Code.GDEditorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Load_95CDED_95Simple_95Keys_951Code.mapOfGDgdjs_9546Load_959595CDED_959595Simple_959595Keys_9595951Code_9546GDEditorObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Editor", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Home"), gdjs.Load_95CDED_95Simple_95Keys_951Code.GDHomeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Load_95CDED_95Simple_95Keys_951Code.mapOfGDgdjs_9546Load_959595CDED_959595Simple_959595Keys_9595951Code_9546GDHomeObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Boot", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Play"), gdjs.Load_95CDED_95Simple_95Keys_951Code.GDPlayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Load_95CDED_95Simple_95Keys_951Code.mapOfGDgdjs_9546Load_959595CDED_959595Simple_959595Keys_9595951Code_9546GDPlayObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Simple Pluck - 1.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Detail_mode"), gdjs.Load_95CDED_95Simple_95Keys_951Code.GDDetail_9595modeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Load_95CDED_95Simple_95Keys_951Code.GDDetail_9595modeObjects1.length;i<l;++i) {
    if ( gdjs.Load_95CDED_95Simple_95Keys_951Code.GDDetail_9595modeObjects1[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Load_95CDED_95Simple_95Keys_951Code.GDDetail_9595modeObjects1[k] = gdjs.Load_95CDED_95Simple_95Keys_951Code.GDDetail_9595modeObjects1[i];
        ++k;
    }
}
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDDetail_9595modeObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Global_Sheet"), gdjs.Load_95CDED_95Simple_95Keys_951Code.GDGlobal_9595SheetObjects1);
{for(var i = 0, len = gdjs.Load_95CDED_95Simple_95Keys_951Code.GDGlobal_9595SheetObjects1.length ;i < len;++i) {
    gdjs.Load_95CDED_95Simple_95Keys_951Code.GDGlobal_9595SheetObjects1[i].getBehavior("Animation").setAnimationIndex(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Detail_mode"), gdjs.Load_95CDED_95Simple_95Keys_951Code.GDDetail_9595modeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Load_95CDED_95Simple_95Keys_951Code.GDDetail_9595modeObjects1.length;i<l;++i) {
    if ( !(gdjs.Load_95CDED_95Simple_95Keys_951Code.GDDetail_9595modeObjects1[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Load_95CDED_95Simple_95Keys_951Code.GDDetail_9595modeObjects1[k] = gdjs.Load_95CDED_95Simple_95Keys_951Code.GDDetail_9595modeObjects1[i];
        ++k;
    }
}
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDDetail_9595modeObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Global_Sheet"), gdjs.Load_95CDED_95Simple_95Keys_951Code.GDGlobal_9595SheetObjects1);
{for(var i = 0, len = gdjs.Load_95CDED_95Simple_95Keys_951Code.GDGlobal_9595SheetObjects1.length ;i < len;++i) {
    gdjs.Load_95CDED_95Simple_95Keys_951Code.GDGlobal_9595SheetObjects1[i].getBehavior("Animation").setAnimationIndex(0);
}
}}

}


};

gdjs.Load_95CDED_95Simple_95Keys_951Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Load_95CDED_95Simple_95Keys_951Code.GDKnobObjects1.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDKnobObjects2.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDNewToggleSwitchObjects1.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDNewToggleSwitchObjects2.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDInstuctionsObjects1.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDInstuctionsObjects2.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDDetail_9595modeObjects1.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDDetail_9595modeObjects2.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDINSTObjects1.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDINSTObjects2.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDPlayObjects1.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDPlayObjects2.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDEditorObjects1.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDEditorObjects2.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDHomeObjects1.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDHomeObjects2.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDGlobal_9595SheetObjects1.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDGlobal_9595SheetObjects2.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDMenuObjects1.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDMenuObjects2.length = 0;

gdjs.Load_95CDED_95Simple_95Keys_951Code.eventsList0(runtimeScene);
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDKnobObjects1.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDKnobObjects2.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDNewToggleSwitchObjects1.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDNewToggleSwitchObjects2.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDInstuctionsObjects1.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDInstuctionsObjects2.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDDetail_9595modeObjects1.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDDetail_9595modeObjects2.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDINSTObjects1.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDINSTObjects2.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDPlayObjects1.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDPlayObjects2.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDEditorObjects1.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDEditorObjects2.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDHomeObjects1.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDHomeObjects2.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDGlobal_9595SheetObjects1.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDGlobal_9595SheetObjects2.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDMenuObjects1.length = 0;
gdjs.Load_95CDED_95Simple_95Keys_951Code.GDMenuObjects2.length = 0;


return;

}

gdjs['Load_95CDED_95Simple_95Keys_951Code'] = gdjs.Load_95CDED_95Simple_95Keys_951Code;
